import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Delete extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
	
        String name = request.getParameter("name");
          
        try
        {
        
            // loading drivers for mysql
            Class.forName("com.mysql.jdbc.Driver");
            
            //creating connection with the database 
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/apartment", "root", "");
            Statement st = con.createStatement();
            String query = "delete from ApartData where name=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, name);
            int i = ps.executeUpdate();            
            if(i > 0)
            {
                response.sendRedirect("HomePage.html");
            }
           con.close();
        
        }
        catch(Exception se) 
        {
            out.println(se);
        }
	
    }
}