import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.*;
import javax.servlet.http.*;

public class Login extends HttpServlet
{
    
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String email = request.getParameter("email");
        String pass = request.getParameter("pass");
        
        
        try
        {
            // loading drivers for mysql
            Class.forName("com.mysql.jdbc.Driver");
            
            //creating connection with the database 
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/apartment", "root", "");
            Statement st = con.createStatement();
            
            ResultSet rs;
            rs = st.executeQuery("select * from apartdata where pass ='" + pass + "'");
               rs.next();
               if (rs.getString("pass").equals(pass))
                {
                  RequestDispatcher rd=request.getRequestDispatcher("HomePage.html"); 
                  rd.forward(request, response); 
                } 
               else
               {
                 out.print("Invalid password.");
                 RequestDispatcher rd=request.getRequestDispatcher("/index.html"); 
                 rd.forward(request, response);
               }
             } 
      catch (Exception e)
      {
          e.printStackTrace();
      }
	
    }
}